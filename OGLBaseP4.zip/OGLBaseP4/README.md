You can activate the virtual tour using 'g' key, and when it is finished you can press it again to move freely throughout the world again.

The terrain is randonmly generated using perlin noise. All code for this can be found in ChunkData, ChunkMesh, and Vertex. I also imported a file called FastNoiseLite that I use for the noise generation. I will expand upon this for my final project.
